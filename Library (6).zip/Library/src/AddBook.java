
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Random;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tropa
 */
public class AddBook extends javax.swing.JFrame {

   Connection conn=null;
   PreparedStatement pst=null;
   ResultSet rs=null;
   
    public AddBook() {
        initComponents();
        conn=javaconnect.ConnecrDb();
        table();
        random();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnadd = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btndlt = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtavlbl = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbldetails = new javax.swing.JTable();
        txtbid = new javax.swing.JTextField();
        txtbname = new javax.swing.JTextField();
        txtprice = new javax.swing.JTextField();
        cmbcategory = new javax.swing.JComboBox<>();
        cmbtype = new javax.swing.JComboBox<>();
        txtoub = new javax.swing.JScrollPane();
        txtpub = new javax.swing.JTextArea();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnadd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnadd.setForeground(new java.awt.Color(0, 102, 102));
        btnadd.setText("ADD BOOK");
        btnadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddActionPerformed(evt);
            }
        });
        jPanel1.add(btnadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 130, -1, -1));

        btnupdate.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnupdate.setForeground(new java.awt.Color(0, 102, 102));
        btnupdate.setText("UPDATE");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 170, -1, -1));

        btndlt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btndlt.setForeground(new java.awt.Color(0, 102, 102));
        btndlt.setText("DELETE");
        btndlt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndltActionPerformed(evt);
            }
        });
        jPanel1.add(btndlt, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 210, -1, -1));

        jLabel11.setFont(new java.awt.Font("Sitka Text", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 102, 102));
        jLabel11.setText("New Book");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 170, -1));

        jLabel13.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel13.setText("Availability");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 240, 110, -1));
        jPanel1.add(txtavlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 130, -1));

        tbldetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbldetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbldetailsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbldetails);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 780, 180));
        jPanel1.add(txtbid, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 130, -1));
        jPanel1.add(txtbname, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 130, -1));

        txtprice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpriceActionPerformed(evt);
            }
        });
        jPanel1.add(txtprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, 130, -1));

        cmbcategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Category", "Technology", "Science Fiction", "History", "Novel" }));
        jPanel1.add(cmbcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 130, 30));

        cmbtype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Book Type", "Borrow", "Return", "Read" }));
        jPanel1.add(cmbtype, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 130, 30));

        txtpub.setColumns(20);
        txtpub.setRows(5);
        txtoub.setViewportView(txtpub);

        jPanel1.add(txtoub, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, 130, 50));

        jDateChooser1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jDateChooser1MouseClicked(evt);
            }
        });
        jPanel1.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 200, 130, -1));

        jLabel5.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel5.setText("Book ID");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));

        jLabel6.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel6.setText("Book Name");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, -1, -1));

        jLabel7.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel7.setText("Category");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        jLabel8.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel8.setText("Book Type");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));

        jLabel9.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel9.setText("Publisher");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 100, -1, 20));

        jLabel10.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel10.setText("Price");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, -1, -1));

        jLabel12.setFont(new java.awt.Font("Sitka Text", 1, 18)); // NOI18N
        jLabel12.setText("Date");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 200, -1, -1));

        jButton2.setText("<");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 40, 50, 20));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 800, 390));

        jLabel2.setForeground(new java.awt.Color(0, 153, 153));
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 800, 70));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtpriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpriceActionPerformed

    private void btnaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddActionPerformed
        String bid= txtbid.getText();
        String bname=txtbname.getText();
        String category=cmbcategory.getSelectedItem().toString();
        String btype=cmbtype.getSelectedItem().toString();
        String pub=txtpub.getText();
        String price=txtprice.getText();
        String date=((JTextField)jDateChooser1.getDateEditor().getUiComponent()).getText();
        String available_qty=txtavlbl.getText();

        
        try{
            String sql="INSERT INTO `addbook`(`bid`, `bname`, `category`, `btype`, `pub`, `price`, `date`, `mark`, `available_qty`) VALUES('"+bid+"','"+bname+"','"+category+"','"+btype+"','"+pub+"','"+price+"','"+date+"','0','"+available_qty+"')";
            PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane,"Book Added Successfully ");

        } catch(SQLException e) {
            JOptionPane.showMessageDialog(rootPane,e);
        }
        clearField();
        table();
        
    }//GEN-LAST:event_btnaddActionPerformed
private void table(){

            try{

                String sql="SELECT `bid`, `bname`, `category`, `btype`, `pub`, `price`, `date`, `available_qty` FROM `addbook`";
                pst=(PreparedStatement)conn.prepareStatement(sql);
                rs=pst.executeQuery();
                tbldetails.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));

            }catch(Exception e) {
                JOptionPane.showMessageDialog(rootPane,e);
            }
            
        }
public void random(){
    Random rd=new Random();
    txtbid.setText(""+rd.nextInt(2000+1));
    }

    private void clearField()
    {
        txtbid.setText("");
        txtbname.setText("");
        cmbtype.setSelectedIndex(0);
        cmbcategory.setSelectedIndex(0);
        ((JTextField)jDateChooser1.getDateEditor().getUiComponent()).setText("");
        txtpub.setText("");
        txtprice.setText("");
        txtavlbl.setText("");
    }

    private void tbldetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbldetailsMouseClicked
        DefaultTableModel tmodel = (DefaultTableModel)tbldetails.getModel();
        int selectrowindex = tbldetails.getSelectedRow();
        
        txtbid.setText(tmodel.getValueAt(selectrowindex, 0).toString());
        txtbname.setText(tmodel.getValueAt(selectrowindex, 1).toString());
        cmbcategory.setSelectedItem(tmodel.getValueAt(selectrowindex, 2).toString());
        cmbtype.setSelectedItem(tmodel.getValueAt(selectrowindex, 3).toString());
        txtpub.setText(tmodel.getValueAt(selectrowindex, 4).toString());
        txtprice.setText(tmodel.getValueAt(selectrowindex, 5).toString());
        ((JTextField)jDateChooser1.getDateEditor().getUiComponent()).setText(tmodel.getValueAt(selectrowindex, 6).toString());
        txtavlbl.setText(tmodel.getValueAt(selectrowindex, 7).toString());
        
        
    }//GEN-LAST:event_tbldetailsMouseClicked

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        String bid= txtbid.getText();
        String bname=txtbname.getText();
        String category=cmbcategory.getSelectedItem().toString();
        String btype=cmbtype.getSelectedItem().toString();
        String pub=txtpub.getText();
        String price=txtprice.getText();
        String date=((JTextField)jDateChooser1.getDateEditor().getUiComponent()).getText();
        String available_qty=txtavlbl.getText();
        
        
        
        try{
            String sql="UPDATE `addbook` SET `bname`='"+bname+"',`category`='"+category+"',`btype`='"+btype+"',`pub`='"+pub+"',`price`='"+price+"',`date`='"+date+"',`available_qty`='"+available_qty+"' WHERE bid='"+bid+"'";
            pst=(PreparedStatement) conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane,"Updated Successfully ");
            table();
            clearField();

        } catch(SQLException e) {
            JOptionPane.showMessageDialog(rootPane,e);
        }
        
    }//GEN-LAST:event_btnupdateActionPerformed

    private void jDateChooser1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jDateChooser1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jDateChooser1MouseClicked

    private void btndltActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndltActionPerformed
        try{
            String sql="DELETE FROM `addbook` WHERE bid='"+txtbid.getText()+"'";
            PreparedStatement pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane,"DELETED Successfully ");
            table();

        } catch(SQLException e) {
            JOptionPane.showMessageDialog(rootPane,e);
        }
        clearField();
    }//GEN-LAST:event_btndltActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddBook().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnadd;
    private javax.swing.JButton btndlt;
    private javax.swing.JButton btnupdate;
    private javax.swing.JComboBox<String> cmbcategory;
    private javax.swing.JComboBox<String> cmbtype;
    private javax.swing.JButton jButton2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbldetails;
    private javax.swing.JTextField txtavlbl;
    private javax.swing.JTextField txtbid;
    private javax.swing.JTextField txtbname;
    private javax.swing.JScrollPane txtoub;
    private javax.swing.JTextField txtprice;
    private javax.swing.JTextArea txtpub;
    // End of variables declaration//GEN-END:variables
}
