
public class openlibrary {
    
    
    
    
    public static void main(String[] args) {
        
       Fpage s=new Fpage();
       s.setVisible(true);
       try{
         for(int i=0;i<=100;i++){  
          Thread.sleep(10);
          s.lbl.setText(Integer.toString(i)+"%");
          s.bar.setValue(i);
          Login l=new Login();
          if(i==100){
              l.setVisible(true);
              s.setVisible(false);
         }
         }
    } catch(Exception e) { 
}
}
}